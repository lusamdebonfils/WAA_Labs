The solution to the problem Lab6_valid
